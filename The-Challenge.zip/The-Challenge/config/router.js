const express =require('express')
const app = express.Router();
const controller = require("../controller/controller")

app.get('/feed',controller.getHomePage)
app.all("/add-message",controller.addNewMessage)
app.get("/feed/:id",controller.showOneMsg)
app.all("/edit/:id",controller.updateOneMessage)
app.get("/delete-post/:id",controller.deleteOnePost)



module.exports = app;